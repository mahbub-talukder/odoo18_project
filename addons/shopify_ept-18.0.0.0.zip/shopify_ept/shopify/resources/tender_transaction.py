from ..base import ShopifyResource


class TenderTransaction(ShopifyResource):
    pass
