from ..base import ShopifyResource


class Receipt(ShopifyResource):
    pass
