from ..base import ShopifyResource


class TaxLine(ShopifyResource):
    pass
