from ..base import ShopifyResource


class Cart(ShopifyResource):
    pass
